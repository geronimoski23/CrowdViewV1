from django.apps import AppConfig


class CrowdvisualrestapiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "crowdvisualrestapi"
